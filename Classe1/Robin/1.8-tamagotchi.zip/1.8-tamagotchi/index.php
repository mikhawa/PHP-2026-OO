<?php 

require_once "tamagotchi.php";


$pixel = new Tamagotchi('Pixel');
echo $pixel->etat() . PHP_EOL;

$pixel->manger();
echo $pixel->etat() . PHP_EOL;

$pixel->jouer();
echo $pixel->etat() . PHP_EOL;


